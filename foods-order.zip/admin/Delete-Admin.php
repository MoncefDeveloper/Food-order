<?php
    include("PDO.php");
    $id=$_GET["id"];
    

    $sql="DELETE FROM `tbl_admin` WHERE `tbl_admin`.`id` = $id";
    $stmt = $db->prepare($sql);
    $stmt->execute();   

    if($stmt==true){
        header("location:http://localhost/food-order/admin/manage-admin.php");
        $_SESSION["drop"]="Drop Admin Succefully";
    }
    else {
        header("location:http://localhost/food-order/admin/manage-admin.php");
        $_SESSION["drop"]="Faile To Drop Admin";
    }    

?>