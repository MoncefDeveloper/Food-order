    <div class="footer">
        <div class="wrapper">
            <p>2020 All Right Reserved, Some Restaurant Developed By - <a href="#">LM</a> </p>
        </div>
    </div>
        <!------------------------------------------------------->
</body>
</html>