<?php
    include("../admin/PDO.php"); 

    session_destroy();
    header("location:http://localhost/food-order/admin/login.php");
?>