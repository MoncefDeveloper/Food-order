        <!-----------------------------------------Footer-Start------------------------------------------------->

        <div class="barre">
            <div class="left">
                <div class="img"><img src="images/facebook-logo.png" ></div>
                <div class="img"><img src="images/instagram-social-network-logo-of-photo-camera.png" ></div>
                <div class="img"><img src="images/placeholder-filled-point.png" width="25px"></div>
        
            </div>

            <h2>LM-RESTAURANT</h2>
        </div>
        <div class="barre2">
            <h2>All rights reserved. Designed By-<a href="#">LM</a></h2>
        </div>

        <!-----------------------------------------Footer-End------------------------------------------------->

    </div>

    <!-- Link our JS files -->
    <script src="js/swiper.js"></script>
    <script src="js/rest.js"></script>
    
</body>
</html>