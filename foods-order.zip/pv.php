<?php include("partials-front/menu-front.php") ?>

<div class="intro" style="background:url('images/Rest-images/simple-.webp') center no-repeat;height:100vh;background-size: cover;justify-content:center">
    <div class="symbol">
        <h2>Underway</h2>
    </div>
</div>

<?php include("partials-front/footer-front.php") ?>